create database usuario;
use usuario;
create table usuario (
nome varchar(40),
email varchar(255) primary key,
senha varchar(255));
select * from usuario;
create database restaurantesif;
use restaurantesif;
