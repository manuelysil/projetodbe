create database restaurantesif;
use restaurantesif;
create table cardapio(id int,nome_prato varchar (100), descricao varchar (100),img varchar (100), preco decimal (6,2));
